

/* Include Prototypes for your library, if applicable */
/* #include "mylibrary.h" */



/*-----------------------------------------------------------------------*

	Place your 'C' library code here.
	
 *-----------------------------------------------------------------------*/


